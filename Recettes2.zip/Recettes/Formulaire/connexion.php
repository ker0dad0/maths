<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire de connexion</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
<div class="container-recette">
                <header>
                    <div class="titre">
                        <h1>BYO<img src="../ressources/flecheBas.svg"></h1>
                        
                        <nav>
                            <a href="../index.html">Accueil</a>
                        </nav>
                    </div>
                    
                </header>
    <section>
        <h1> Connexion</h1>
        <form action="config.php" method="POST">
            <label for="email">Adresse e-mail</label>
            <input type="text" name="email">
            <label for="password">Mot de passe</label>
            <input type="password" name="mdp">
            <input type="submit" name="Valider" value="Se connecter">
            <a href="creer.php">Nouveau!! créer un compte</a>
    </section>
    
</body>
</html>