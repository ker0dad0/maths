# Candidature formation "Développeur web" chez OpenClassrooms.



![screenshot du site](./ressources/screenshot.png)



## Technologies :
- HTML
- CSS
- JS



## Tester le projet :

```terminal
git clone https://github.com/Cyril-Develop/cookingRecipesWebsite-JS.git
```

